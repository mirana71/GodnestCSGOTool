﻿namespace GodnestCSGOTool
{
    partial class mainform
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(mainform));
            this.materialTabSelector1 = new MaterialSkin.Controls.MaterialTabSelector();
            this.materialTabControl1 = new MaterialSkin.Controls.MaterialTabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.label4 = new System.Windows.Forms.Label();
            this.materialRaisedButton8 = new MaterialSkin.Controls.MaterialRaisedButton();
            this.launchsteam = new MaterialSkin.Controls.MaterialRaisedButton();
            this.launchcsgo = new MaterialSkin.Controls.MaterialRaisedButton();
            this.button1 = new MaterialSkin.Controls.MaterialRaisedButton();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.materialRaisedButton34 = new MaterialSkin.Controls.MaterialRaisedButton();
            this.materialRaisedButton33 = new MaterialSkin.Controls.MaterialRaisedButton();
            this.materialRaisedButton5 = new MaterialSkin.Controls.MaterialRaisedButton();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.materialLabel1 = new MaterialSkin.Controls.MaterialLabel();
            this.materialRaisedButton16 = new MaterialSkin.Controls.MaterialRaisedButton();
            this.materialRaisedButton15 = new MaterialSkin.Controls.MaterialRaisedButton();
            this.materialRaisedButton14 = new MaterialSkin.Controls.MaterialRaisedButton();
            this.checkBox4 = new System.Windows.Forms.CheckBox();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.materialLabel3 = new MaterialSkin.Controls.MaterialLabel();
            this.materialLabel2 = new MaterialSkin.Controls.MaterialLabel();
            this.materialRaisedButton4 = new MaterialSkin.Controls.MaterialRaisedButton();
            this.materialRaisedButton3 = new MaterialSkin.Controls.MaterialRaisedButton();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.checkBox3 = new System.Windows.Forms.CheckBox();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.materialRaisedButton2 = new MaterialSkin.Controls.MaterialRaisedButton();
            this.materialRaisedButton1 = new MaterialSkin.Controls.MaterialRaisedButton();
            this.listBox3 = new System.Windows.Forms.ListBox();
            this.listBox2 = new System.Windows.Forms.ListBox();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.label1 = new System.Windows.Forms.Label();
            this.materialRaisedButton6 = new MaterialSkin.Controls.MaterialRaisedButton();
            this.materialRaisedButton10 = new MaterialSkin.Controls.MaterialRaisedButton();
            this.materialRaisedButton9 = new MaterialSkin.Controls.MaterialRaisedButton();
            this.listBox4 = new System.Windows.Forms.ListBox();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.label2 = new System.Windows.Forms.Label();
            this.materialRaisedButton7 = new MaterialSkin.Controls.MaterialRaisedButton();
            this.materialRaisedButton13 = new MaterialSkin.Controls.MaterialRaisedButton();
            this.materialRaisedButton12 = new MaterialSkin.Controls.MaterialRaisedButton();
            this.listBox5 = new System.Windows.Forms.ListBox();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.textBox22 = new System.Windows.Forms.TextBox();
            this.button9 = new System.Windows.Forms.Button();
            this.materialRaisedButton36 = new MaterialSkin.Controls.MaterialRaisedButton();
            this.button6 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.materialRaisedButton28 = new MaterialSkin.Controls.MaterialRaisedButton();
            this.checkBox6 = new System.Windows.Forms.CheckBox();
            this.checkBox5 = new System.Windows.Forms.CheckBox();
            this.listBox8 = new System.Windows.Forms.ListBox();
            this.button7 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.textBox16 = new System.Windows.Forms.TextBox();
            this.textBox15 = new System.Windows.Forms.TextBox();
            this.listBox7 = new System.Windows.Forms.ListBox();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.materialRaisedButton20 = new MaterialSkin.Controls.MaterialRaisedButton();
            this.label7 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.textBox14 = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.materialRaisedButton18 = new MaterialSkin.Controls.MaterialRaisedButton();
            this.materialRaisedButton17 = new MaterialSkin.Controls.MaterialRaisedButton();
            this.textBox13 = new System.Windows.Forms.TextBox();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.listBox6 = new System.Windows.Forms.ListBox();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.materialRaisedButton11 = new MaterialSkin.Controls.MaterialRaisedButton();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.materialRaisedButton39 = new MaterialSkin.Controls.MaterialRaisedButton();
            this.textBox26 = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.checkBox16 = new System.Windows.Forms.CheckBox();
            this.checkBox15 = new System.Windows.Forms.CheckBox();
            this.checkBox14 = new System.Windows.Forms.CheckBox();
            this.label16 = new System.Windows.Forms.Label();
            this.checkBox13 = new System.Windows.Forms.CheckBox();
            this.checkBox12 = new System.Windows.Forms.CheckBox();
            this.materialRaisedButton35 = new MaterialSkin.Controls.MaterialRaisedButton();
            this.textBox25 = new System.Windows.Forms.TextBox();
            this.textBox24 = new System.Windows.Forms.TextBox();
            this.checkBox11 = new System.Windows.Forms.CheckBox();
            this.checkBox7 = new System.Windows.Forms.CheckBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.materialRaisedButton32 = new MaterialSkin.Controls.MaterialRaisedButton();
            this.label13 = new System.Windows.Forms.Label();
            this.materialRaisedButton31 = new MaterialSkin.Controls.MaterialRaisedButton();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.textBox21 = new System.Windows.Forms.TextBox();
            this.materialRaisedButton30 = new MaterialSkin.Controls.MaterialRaisedButton();
            this.materialRaisedButton29 = new MaterialSkin.Controls.MaterialRaisedButton();
            this.listBox13 = new System.Windows.Forms.ListBox();
            this.textBox20 = new System.Windows.Forms.TextBox();
            this.materialRaisedButton27 = new MaterialSkin.Controls.MaterialRaisedButton();
            this.materialRaisedButton26 = new MaterialSkin.Controls.MaterialRaisedButton();
            this.listBox12 = new System.Windows.Forms.ListBox();
            this.materialRaisedButton25 = new MaterialSkin.Controls.MaterialRaisedButton();
            this.materialRaisedButton24 = new MaterialSkin.Controls.MaterialRaisedButton();
            this.materialRaisedButton23 = new MaterialSkin.Controls.MaterialRaisedButton();
            this.listBox11 = new System.Windows.Forms.ListBox();
            this.textBox19 = new System.Windows.Forms.TextBox();
            this.textBox18 = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.materialRaisedButton22 = new MaterialSkin.Controls.MaterialRaisedButton();
            this.textBox17 = new System.Windows.Forms.TextBox();
            this.listBox10 = new System.Windows.Forms.ListBox();
            this.checkBox8 = new System.Windows.Forms.CheckBox();
            this.checkBox9 = new System.Windows.Forms.CheckBox();
            this.checkBox10 = new System.Windows.Forms.CheckBox();
            this.materialRaisedButton21 = new MaterialSkin.Controls.MaterialRaisedButton();
            this.materialRaisedButton19 = new MaterialSkin.Controls.MaterialRaisedButton();
            this.label5 = new System.Windows.Forms.Label();
            this.listBox9 = new System.Windows.Forms.ListBox();
            this.tabPage7 = new System.Windows.Forms.TabPage();
            this.materialRaisedButton38 = new MaterialSkin.Controls.MaterialRaisedButton();
            this.textBox23 = new System.Windows.Forms.TextBox();
            this.materialRaisedButton37 = new MaterialSkin.Controls.MaterialRaisedButton();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.folderBrowserDialog1 = new System.Windows.Forms.FolderBrowserDialog();
            this.timer2 = new System.Windows.Forms.Timer(this.components);
            this.folderBrowserDialog2 = new System.Windows.Forms.FolderBrowserDialog();
            this.materialTabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.tabPage5.SuspendLayout();
            this.tabPage6.SuspendLayout();
            this.tabPage7.SuspendLayout();
            this.SuspendLayout();
            // 
            // materialTabSelector1
            // 
            this.materialTabSelector1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)));
            this.materialTabSelector1.BaseTabControl = this.materialTabControl1;
            this.materialTabSelector1.Depth = 0;
            this.materialTabSelector1.Location = new System.Drawing.Point(0, 56);
            this.materialTabSelector1.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialTabSelector1.Name = "materialTabSelector1";
            this.materialTabSelector1.Size = new System.Drawing.Size(999, 31);
            this.materialTabSelector1.TabIndex = 0;
            this.materialTabSelector1.Text = "materialTabSelector1";
            this.materialTabSelector1.Click += new System.EventHandler(this.materialTabSelector1_Click);
            // 
            // materialTabControl1
            // 
            this.materialTabControl1.Controls.Add(this.tabPage1);
            this.materialTabControl1.Controls.Add(this.tabPage2);
            this.materialTabControl1.Controls.Add(this.tabPage3);
            this.materialTabControl1.Controls.Add(this.tabPage4);
            this.materialTabControl1.Controls.Add(this.tabPage5);
            this.materialTabControl1.Controls.Add(this.tabPage6);
            this.materialTabControl1.Controls.Add(this.tabPage7);
            this.materialTabControl1.Depth = 0;
            this.materialTabControl1.Location = new System.Drawing.Point(0, 84);
            this.materialTabControl1.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialTabControl1.Name = "materialTabControl1";
            this.materialTabControl1.SelectedIndex = 0;
            this.materialTabControl1.Size = new System.Drawing.Size(992, 490);
            this.materialTabControl1.TabIndex = 0;
            this.materialTabControl1.Enter += new System.EventHandler(this.materialTabControl1_Enter);
            this.materialTabControl1.Leave += new System.EventHandler(this.materialTabControl1_Leave);
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.label4);
            this.tabPage1.Controls.Add(this.materialRaisedButton8);
            this.tabPage1.Controls.Add(this.launchsteam);
            this.tabPage1.Controls.Add(this.launchcsgo);
            this.tabPage1.Controls.Add(this.button1);
            this.tabPage1.Controls.Add(this.listBox1);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(984, 464);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "tabPage1";
            this.tabPage1.UseVisualStyleBackColor = true;
            this.tabPage1.Click += new System.EventHandler(this.tabPage1_Click);
            // 
            // label4
            // 
            this.label4.BackColor = System.Drawing.Color.White;
            this.label4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label4.Location = new System.Drawing.Point(6, 438);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(841, 20);
            this.label4.TabIndex = 32;
            this.label4.Text = "Status";
            // 
            // materialRaisedButton8
            // 
            this.materialRaisedButton8.Depth = 0;
            this.materialRaisedButton8.Location = new System.Drawing.Point(853, 157);
            this.materialRaisedButton8.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialRaisedButton8.Name = "materialRaisedButton8";
            this.materialRaisedButton8.Primary = true;
            this.materialRaisedButton8.Size = new System.Drawing.Size(123, 28);
            this.materialRaisedButton8.TabIndex = 9;
            this.materialRaisedButton8.Text = "OW bypass";
            this.materialRaisedButton8.UseVisualStyleBackColor = true;
            this.materialRaisedButton8.Click += new System.EventHandler(this.materialRaisedButton8_Click);
            // 
            // launchsteam
            // 
            this.launchsteam.Depth = 0;
            this.launchsteam.Location = new System.Drawing.Point(853, 51);
            this.launchsteam.MouseState = MaterialSkin.MouseState.HOVER;
            this.launchsteam.Name = "launchsteam";
            this.launchsteam.Primary = true;
            this.launchsteam.Size = new System.Drawing.Size(123, 47);
            this.launchsteam.TabIndex = 8;
            this.launchsteam.Text = "Start Steam";
            this.launchsteam.UseVisualStyleBackColor = true;
            this.launchsteam.Click += new System.EventHandler(this.materialRaisedButton6_Click);
            // 
            // launchcsgo
            // 
            this.launchcsgo.Depth = 0;
            this.launchcsgo.Location = new System.Drawing.Point(853, 104);
            this.launchcsgo.MouseState = MaterialSkin.MouseState.HOVER;
            this.launchcsgo.Name = "launchcsgo";
            this.launchcsgo.Primary = true;
            this.launchcsgo.Size = new System.Drawing.Size(123, 47);
            this.launchcsgo.TabIndex = 7;
            this.launchcsgo.Text = "Start CS:GO";
            this.launchcsgo.UseVisualStyleBackColor = true;
            this.launchcsgo.Click += new System.EventHandler(this.materialRaisedButton6_Click);
            // 
            // button1
            // 
            this.button1.Depth = 0;
            this.button1.Location = new System.Drawing.Point(853, 6);
            this.button1.MouseState = MaterialSkin.MouseState.HOVER;
            this.button1.Name = "button1";
            this.button1.Primary = true;
            this.button1.Size = new System.Drawing.Size(123, 39);
            this.button1.TabIndex = 6;
            this.button1.Text = "Check for OW delay";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.materialRaisedButton5_Click);
            // 
            // listBox1
            // 
            this.listBox1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.listBox1.FormattingEnabled = true;
            this.listBox1.Location = new System.Drawing.Point(6, 6);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(841, 429);
            this.listBox1.TabIndex = 0;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.materialRaisedButton34);
            this.tabPage2.Controls.Add(this.materialRaisedButton33);
            this.tabPage2.Controls.Add(this.materialRaisedButton5);
            this.tabPage2.Controls.Add(this.textBox9);
            this.tabPage2.Controls.Add(this.materialLabel1);
            this.tabPage2.Controls.Add(this.materialRaisedButton16);
            this.tabPage2.Controls.Add(this.materialRaisedButton15);
            this.tabPage2.Controls.Add(this.materialRaisedButton14);
            this.tabPage2.Controls.Add(this.checkBox4);
            this.tabPage2.Controls.Add(this.textBox8);
            this.tabPage2.Controls.Add(this.textBox7);
            this.tabPage2.Controls.Add(this.textBox3);
            this.tabPage2.Controls.Add(this.textBox6);
            this.tabPage2.Controls.Add(this.textBox5);
            this.tabPage2.Controls.Add(this.textBox4);
            this.tabPage2.Controls.Add(this.textBox2);
            this.tabPage2.Controls.Add(this.textBox1);
            this.tabPage2.Controls.Add(this.label3);
            this.tabPage2.Controls.Add(this.materialLabel3);
            this.tabPage2.Controls.Add(this.materialLabel2);
            this.tabPage2.Controls.Add(this.materialRaisedButton4);
            this.tabPage2.Controls.Add(this.materialRaisedButton3);
            this.tabPage2.Controls.Add(this.checkBox1);
            this.tabPage2.Controls.Add(this.checkBox3);
            this.tabPage2.Controls.Add(this.checkBox2);
            this.tabPage2.Controls.Add(this.materialRaisedButton2);
            this.tabPage2.Controls.Add(this.materialRaisedButton1);
            this.tabPage2.Controls.Add(this.listBox3);
            this.tabPage2.Controls.Add(this.listBox2);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(984, 464);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "tabPage2";
            this.tabPage2.UseVisualStyleBackColor = true;
            this.tabPage2.Click += new System.EventHandler(this.tabPage2_Click);
            // 
            // materialRaisedButton34
            // 
            this.materialRaisedButton34.Depth = 0;
            this.materialRaisedButton34.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.materialRaisedButton34.ForeColor = System.Drawing.Color.CornflowerBlue;
            this.materialRaisedButton34.Location = new System.Drawing.Point(785, 34);
            this.materialRaisedButton34.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialRaisedButton34.Name = "materialRaisedButton34";
            this.materialRaisedButton34.Primary = true;
            this.materialRaisedButton34.Size = new System.Drawing.Size(135, 29);
            this.materialRaisedButton34.TabIndex = 94;
            this.materialRaisedButton34.Text = "SteamID Path";
            this.materialRaisedButton34.UseVisualStyleBackColor = true;
            this.materialRaisedButton34.Click += new System.EventHandler(this.materialRaisedButton34_Click);
            // 
            // materialRaisedButton33
            // 
            this.materialRaisedButton33.Depth = 0;
            this.materialRaisedButton33.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.materialRaisedButton33.ForeColor = System.Drawing.Color.CornflowerBlue;
            this.materialRaisedButton33.Location = new System.Drawing.Point(785, 3);
            this.materialRaisedButton33.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialRaisedButton33.Name = "materialRaisedButton33";
            this.materialRaisedButton33.Primary = true;
            this.materialRaisedButton33.Size = new System.Drawing.Size(135, 29);
            this.materialRaisedButton33.TabIndex = 93;
            this.materialRaisedButton33.Text = "Status Path";
            this.materialRaisedButton33.UseVisualStyleBackColor = true;
            this.materialRaisedButton33.Click += new System.EventHandler(this.materialRaisedButton33_Click);
            // 
            // materialRaisedButton5
            // 
            this.materialRaisedButton5.Depth = 0;
            this.materialRaisedButton5.Location = new System.Drawing.Point(548, 420);
            this.materialRaisedButton5.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialRaisedButton5.Name = "materialRaisedButton5";
            this.materialRaisedButton5.Primary = true;
            this.materialRaisedButton5.Size = new System.Drawing.Size(231, 20);
            this.materialRaisedButton5.TabIndex = 40;
            this.materialRaisedButton5.Text = "Check Accounts";
            this.materialRaisedButton5.UseVisualStyleBackColor = true;
            this.materialRaisedButton5.Click += new System.EventHandler(this.materialRaisedButton5_Click_1);
            // 
            // textBox9
            // 
            this.textBox9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox9.Location = new System.Drawing.Point(733, 444);
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(46, 20);
            this.textBox9.TabIndex = 39;
            this.textBox9.TextChanged += new System.EventHandler(this.textBox9_TextChanged);
            // 
            // materialLabel1
            // 
            this.materialLabel1.Depth = 0;
            this.materialLabel1.Font = new System.Drawing.Font("Roboto", 11F);
            this.materialLabel1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.materialLabel1.Location = new System.Drawing.Point(548, 202);
            this.materialLabel1.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel1.Name = "materialLabel1";
            this.materialLabel1.Size = new System.Drawing.Size(231, 25);
            this.materialLabel1.TabIndex = 38;
            this.materialLabel1.Text = "Mail";
            this.materialLabel1.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // materialRaisedButton16
            // 
            this.materialRaisedButton16.Depth = 0;
            this.materialRaisedButton16.Location = new System.Drawing.Point(548, 383);
            this.materialRaisedButton16.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialRaisedButton16.Name = "materialRaisedButton16";
            this.materialRaisedButton16.Primary = true;
            this.materialRaisedButton16.Size = new System.Drawing.Size(231, 20);
            this.materialRaisedButton16.TabIndex = 37;
            this.materialRaisedButton16.Text = "Path to steam";
            this.materialRaisedButton16.UseVisualStyleBackColor = true;
            this.materialRaisedButton16.Click += new System.EventHandler(this.materialRaisedButton16_Click);
            // 
            // materialRaisedButton15
            // 
            this.materialRaisedButton15.Depth = 0;
            this.materialRaisedButton15.Location = new System.Drawing.Point(548, 357);
            this.materialRaisedButton15.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialRaisedButton15.Name = "materialRaisedButton15";
            this.materialRaisedButton15.Primary = true;
            this.materialRaisedButton15.Size = new System.Drawing.Size(231, 20);
            this.materialRaisedButton15.TabIndex = 36;
            this.materialRaisedButton15.Text = "Remove mail";
            this.materialRaisedButton15.UseVisualStyleBackColor = true;
            this.materialRaisedButton15.Click += new System.EventHandler(this.materialRaisedButton15_Click);
            // 
            // materialRaisedButton14
            // 
            this.materialRaisedButton14.Depth = 0;
            this.materialRaisedButton14.Location = new System.Drawing.Point(548, 331);
            this.materialRaisedButton14.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialRaisedButton14.Name = "materialRaisedButton14";
            this.materialRaisedButton14.Primary = true;
            this.materialRaisedButton14.Size = new System.Drawing.Size(231, 20);
            this.materialRaisedButton14.TabIndex = 35;
            this.materialRaisedButton14.Text = "Check and apply";
            this.materialRaisedButton14.UseVisualStyleBackColor = true;
            this.materialRaisedButton14.Click += new System.EventHandler(this.materialRaisedButton14_Click);
            // 
            // checkBox4
            // 
            this.checkBox4.AutoSize = true;
            this.checkBox4.BackColor = System.Drawing.Color.White;
            this.checkBox4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.checkBox4.Location = new System.Drawing.Point(548, 308);
            this.checkBox4.Name = "checkBox4";
            this.checkBox4.Size = new System.Drawing.Size(85, 17);
            this.checkBox4.TabIndex = 34;
            this.checkBox4.Text = "SSL Protocol";
            this.checkBox4.UseVisualStyleBackColor = false;
            // 
            // textBox8
            // 
            this.textBox8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox8.Location = new System.Drawing.Point(548, 282);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(231, 20);
            this.textBox8.TabIndex = 33;
            this.textBox8.Text = "POP3 Protocol";
            // 
            // textBox7
            // 
            this.textBox7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox7.Location = new System.Drawing.Point(548, 256);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(231, 20);
            this.textBox7.TabIndex = 32;
            this.textBox7.Text = "Mail password";
            // 
            // textBox3
            // 
            this.textBox3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox3.Location = new System.Drawing.Point(548, 230);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(231, 20);
            this.textBox3.TabIndex = 31;
            this.textBox3.Text = "Mail login";
            // 
            // textBox6
            // 
            this.textBox6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox6.Location = new System.Drawing.Point(548, 127);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(231, 20);
            this.textBox6.TabIndex = 23;
            this.textBox6.Text = "POP3 Protocol";
            // 
            // textBox5
            // 
            this.textBox5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox5.Location = new System.Drawing.Point(548, 101);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(231, 20);
            this.textBox5.TabIndex = 22;
            this.textBox5.Text = "Mail password";
            // 
            // textBox4
            // 
            this.textBox4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox4.Location = new System.Drawing.Point(548, 75);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(231, 20);
            this.textBox4.TabIndex = 21;
            this.textBox4.Text = "Mail login";
            this.textBox4.TextChanged += new System.EventHandler(this.textBox4_TextChanged);
            // 
            // textBox2
            // 
            this.textBox2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox2.Location = new System.Drawing.Point(548, 26);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(231, 20);
            this.textBox2.TabIndex = 8;
            this.textBox2.Text = "Password";
            // 
            // textBox1
            // 
            this.textBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox1.Location = new System.Drawing.Point(548, 3);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(231, 20);
            this.textBox1.TabIndex = 7;
            this.textBox1.Text = "Login";
            // 
            // label3
            // 
            this.label3.BackColor = System.Drawing.Color.White;
            this.label3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label3.Location = new System.Drawing.Point(164, 444);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(574, 20);
            this.label3.TabIndex = 30;
            this.label3.Text = "Status";
            // 
            // materialLabel3
            // 
            this.materialLabel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.materialLabel3.Depth = 0;
            this.materialLabel3.Font = new System.Drawing.Font("Roboto", 11F);
            this.materialLabel3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.materialLabel3.Location = new System.Drawing.Point(376, 421);
            this.materialLabel3.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel3.Name = "materialLabel3";
            this.materialLabel3.Size = new System.Drawing.Size(166, 19);
            this.materialLabel3.TabIndex = 29;
            this.materialLabel3.Text = "Not using =";
            // 
            // materialLabel2
            // 
            this.materialLabel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.materialLabel2.Depth = 0;
            this.materialLabel2.Font = new System.Drawing.Font("Roboto", 11F);
            this.materialLabel2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.materialLabel2.Location = new System.Drawing.Point(164, 421);
            this.materialLabel2.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel2.Name = "materialLabel2";
            this.materialLabel2.Size = new System.Drawing.Size(166, 19);
            this.materialLabel2.TabIndex = 28;
            this.materialLabel2.Text = "Using =";
            // 
            // materialRaisedButton4
            // 
            this.materialRaisedButton4.Depth = 0;
            this.materialRaisedButton4.Location = new System.Drawing.Point(548, 179);
            this.materialRaisedButton4.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialRaisedButton4.Name = "materialRaisedButton4";
            this.materialRaisedButton4.Primary = true;
            this.materialRaisedButton4.Size = new System.Drawing.Size(231, 20);
            this.materialRaisedButton4.TabIndex = 27;
            this.materialRaisedButton4.Text = "Remove";
            this.materialRaisedButton4.UseVisualStyleBackColor = true;
            this.materialRaisedButton4.Click += new System.EventHandler(this.materialRaisedButton4_Click);
            // 
            // materialRaisedButton3
            // 
            this.materialRaisedButton3.Depth = 0;
            this.materialRaisedButton3.Location = new System.Drawing.Point(548, 153);
            this.materialRaisedButton3.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialRaisedButton3.Name = "materialRaisedButton3";
            this.materialRaisedButton3.Primary = true;
            this.materialRaisedButton3.Size = new System.Drawing.Size(231, 20);
            this.materialRaisedButton3.TabIndex = 26;
            this.materialRaisedButton3.Text = "Add";
            this.materialRaisedButton3.UseVisualStyleBackColor = true;
            this.materialRaisedButton3.Click += new System.EventHandler(this.materialRaisedButton3_Click);
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.BackColor = System.Drawing.Color.White;
            this.checkBox1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.checkBox1.Location = new System.Drawing.Point(548, 52);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(53, 17);
            this.checkBox1.TabIndex = 25;
            this.checkBox1.Text = "Mail";
            this.checkBox1.UseVisualStyleBackColor = false;
            // 
            // checkBox3
            // 
            this.checkBox3.AutoSize = true;
            this.checkBox3.BackColor = System.Drawing.Color.White;
            this.checkBox3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.checkBox3.Location = new System.Drawing.Point(607, 52);
            this.checkBox3.Name = "checkBox3";
            this.checkBox3.Size = new System.Drawing.Size(43, 17);
            this.checkBox3.TabIndex = 24;
            this.checkBox3.Text = "SSL";
            this.checkBox3.UseVisualStyleBackColor = false;
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.BackColor = System.Drawing.Color.White;
            this.checkBox2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.checkBox2.Location = new System.Drawing.Point(656, 52);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(115, 17);
            this.checkBox2.TabIndex = 20;
            this.checkBox2.Text = "Mail";
            this.checkBox2.UseVisualStyleBackColor = false;
            // 
            // materialRaisedButton2
            // 
            this.materialRaisedButton2.Depth = 0;
            this.materialRaisedButton2.Location = new System.Drawing.Point(336, 3);
            this.materialRaisedButton2.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialRaisedButton2.Name = "materialRaisedButton2";
            this.materialRaisedButton2.Primary = true;
            this.materialRaisedButton2.Size = new System.Drawing.Size(34, 30);
            this.materialRaisedButton2.TabIndex = 3;
            this.materialRaisedButton2.Text = "<";
            this.materialRaisedButton2.UseVisualStyleBackColor = true;
            this.materialRaisedButton2.Click += new System.EventHandler(this.materialRaisedButton2_Click);
            // 
            // materialRaisedButton1
            // 
            this.materialRaisedButton1.Depth = 0;
            this.materialRaisedButton1.Location = new System.Drawing.Point(336, 39);
            this.materialRaisedButton1.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialRaisedButton1.Name = "materialRaisedButton1";
            this.materialRaisedButton1.Primary = true;
            this.materialRaisedButton1.Size = new System.Drawing.Size(34, 30);
            this.materialRaisedButton1.TabIndex = 2;
            this.materialRaisedButton1.Text = ">";
            this.materialRaisedButton1.UseVisualStyleBackColor = true;
            this.materialRaisedButton1.Click += new System.EventHandler(this.materialRaisedButton1_Click);
            // 
            // listBox3
            // 
            this.listBox3.FormattingEnabled = true;
            this.listBox3.Location = new System.Drawing.Point(164, 3);
            this.listBox3.Name = "listBox3";
            this.listBox3.Size = new System.Drawing.Size(166, 420);
            this.listBox3.TabIndex = 1;
            // 
            // listBox2
            // 
            this.listBox2.FormattingEnabled = true;
            this.listBox2.Location = new System.Drawing.Point(376, 3);
            this.listBox2.Name = "listBox2";
            this.listBox2.Size = new System.Drawing.Size(166, 420);
            this.listBox2.TabIndex = 0;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.label1);
            this.tabPage3.Controls.Add(this.materialRaisedButton6);
            this.tabPage3.Controls.Add(this.materialRaisedButton10);
            this.tabPage3.Controls.Add(this.materialRaisedButton9);
            this.tabPage3.Controls.Add(this.listBox4);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(984, 464);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "tabPage3";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.White;
            this.label1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label1.Location = new System.Drawing.Point(6, 438);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(841, 20);
            this.label1.TabIndex = 31;
            this.label1.Text = "Status";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // materialRaisedButton6
            // 
            this.materialRaisedButton6.Depth = 0;
            this.materialRaisedButton6.Location = new System.Drawing.Point(853, 96);
            this.materialRaisedButton6.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialRaisedButton6.Name = "materialRaisedButton6";
            this.materialRaisedButton6.Primary = true;
            this.materialRaisedButton6.Size = new System.Drawing.Size(131, 39);
            this.materialRaisedButton6.TabIndex = 9;
            this.materialRaisedButton6.Text = "Reset timer";
            this.materialRaisedButton6.UseVisualStyleBackColor = true;
            this.materialRaisedButton6.Click += new System.EventHandler(this.materialRaisedButton6_Click_1);
            // 
            // materialRaisedButton10
            // 
            this.materialRaisedButton10.Depth = 0;
            this.materialRaisedButton10.Location = new System.Drawing.Point(853, 51);
            this.materialRaisedButton10.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialRaisedButton10.Name = "materialRaisedButton10";
            this.materialRaisedButton10.Primary = true;
            this.materialRaisedButton10.Size = new System.Drawing.Size(131, 39);
            this.materialRaisedButton10.TabIndex = 8;
            this.materialRaisedButton10.Text = "Steam3ID";
            this.materialRaisedButton10.UseVisualStyleBackColor = true;
            this.materialRaisedButton10.Click += new System.EventHandler(this.materialRaisedButton10_Click);
            // 
            // materialRaisedButton9
            // 
            this.materialRaisedButton9.Depth = 0;
            this.materialRaisedButton9.Location = new System.Drawing.Point(853, 6);
            this.materialRaisedButton9.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialRaisedButton9.Name = "materialRaisedButton9";
            this.materialRaisedButton9.Primary = true;
            this.materialRaisedButton9.Size = new System.Drawing.Size(131, 39);
            this.materialRaisedButton9.TabIndex = 7;
            this.materialRaisedButton9.Text = "Report with bots";
            this.materialRaisedButton9.UseVisualStyleBackColor = true;
            this.materialRaisedButton9.Click += new System.EventHandler(this.materialRaisedButton9_Click);
            // 
            // listBox4
            // 
            this.listBox4.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.listBox4.FormattingEnabled = true;
            this.listBox4.Location = new System.Drawing.Point(6, 6);
            this.listBox4.Name = "listBox4";
            this.listBox4.Size = new System.Drawing.Size(841, 429);
            this.listBox4.TabIndex = 1;
            this.listBox4.UseTabStops = false;
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.label2);
            this.tabPage4.Controls.Add(this.materialRaisedButton7);
            this.tabPage4.Controls.Add(this.materialRaisedButton13);
            this.tabPage4.Controls.Add(this.materialRaisedButton12);
            this.tabPage4.Controls.Add(this.listBox5);
            this.tabPage4.Location = new System.Drawing.Point(4, 22);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(984, 464);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "tabPage4";
            this.tabPage4.UseVisualStyleBackColor = true;
            this.tabPage4.Click += new System.EventHandler(this.tabPage4_Click);
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.Color.White;
            this.label2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label2.Location = new System.Drawing.Point(6, 438);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(841, 20);
            this.label2.TabIndex = 32;
            this.label2.Text = "Status";
            // 
            // materialRaisedButton7
            // 
            this.materialRaisedButton7.Depth = 0;
            this.materialRaisedButton7.Location = new System.Drawing.Point(853, 96);
            this.materialRaisedButton7.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialRaisedButton7.Name = "materialRaisedButton7";
            this.materialRaisedButton7.Primary = true;
            this.materialRaisedButton7.Size = new System.Drawing.Size(131, 39);
            this.materialRaisedButton7.TabIndex = 10;
            this.materialRaisedButton7.Text = "Reset timer";
            this.materialRaisedButton7.UseVisualStyleBackColor = true;
            this.materialRaisedButton7.Click += new System.EventHandler(this.materialRaisedButton7_Click_1);
            // 
            // materialRaisedButton13
            // 
            this.materialRaisedButton13.Depth = 0;
            this.materialRaisedButton13.Location = new System.Drawing.Point(853, 51);
            this.materialRaisedButton13.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialRaisedButton13.Name = "materialRaisedButton13";
            this.materialRaisedButton13.Primary = true;
            this.materialRaisedButton13.Size = new System.Drawing.Size(131, 39);
            this.materialRaisedButton13.TabIndex = 9;
            this.materialRaisedButton13.Text = "Steam3ID";
            this.materialRaisedButton13.UseVisualStyleBackColor = true;
            this.materialRaisedButton13.Click += new System.EventHandler(this.materialRaisedButton13_Click);
            // 
            // materialRaisedButton12
            // 
            this.materialRaisedButton12.Depth = 0;
            this.materialRaisedButton12.ForeColor = System.Drawing.Color.CornflowerBlue;
            this.materialRaisedButton12.Location = new System.Drawing.Point(853, 6);
            this.materialRaisedButton12.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialRaisedButton12.Name = "materialRaisedButton12";
            this.materialRaisedButton12.Primary = true;
            this.materialRaisedButton12.Size = new System.Drawing.Size(131, 39);
            this.materialRaisedButton12.TabIndex = 8;
            this.materialRaisedButton12.Text = "Like";
            this.materialRaisedButton12.UseVisualStyleBackColor = true;
            this.materialRaisedButton12.Click += new System.EventHandler(this.materialRaisedButton12_Click);
            // 
            // listBox5
            // 
            this.listBox5.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.listBox5.FormattingEnabled = true;
            this.listBox5.Location = new System.Drawing.Point(6, 6);
            this.listBox5.Name = "listBox5";
            this.listBox5.Size = new System.Drawing.Size(841, 429);
            this.listBox5.TabIndex = 2;
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.textBox22);
            this.tabPage5.Controls.Add(this.button9);
            this.tabPage5.Controls.Add(this.materialRaisedButton36);
            this.tabPage5.Controls.Add(this.button6);
            this.tabPage5.Controls.Add(this.button5);
            this.tabPage5.Controls.Add(this.materialRaisedButton28);
            this.tabPage5.Controls.Add(this.checkBox6);
            this.tabPage5.Controls.Add(this.checkBox5);
            this.tabPage5.Controls.Add(this.listBox8);
            this.tabPage5.Controls.Add(this.button7);
            this.tabPage5.Controls.Add(this.button3);
            this.tabPage5.Controls.Add(this.textBox16);
            this.tabPage5.Controls.Add(this.textBox15);
            this.tabPage5.Controls.Add(this.listBox7);
            this.tabPage5.Controls.Add(this.textBox12);
            this.tabPage5.Controls.Add(this.materialRaisedButton20);
            this.tabPage5.Controls.Add(this.label7);
            this.tabPage5.Controls.Add(this.button2);
            this.tabPage5.Controls.Add(this.textBox14);
            this.tabPage5.Controls.Add(this.label6);
            this.tabPage5.Controls.Add(this.materialRaisedButton18);
            this.tabPage5.Controls.Add(this.materialRaisedButton17);
            this.tabPage5.Controls.Add(this.textBox13);
            this.tabPage5.Controls.Add(this.textBox11);
            this.tabPage5.Controls.Add(this.comboBox1);
            this.tabPage5.Controls.Add(this.listBox6);
            this.tabPage5.Controls.Add(this.textBox10);
            this.tabPage5.Controls.Add(this.materialRaisedButton11);
            this.tabPage5.Location = new System.Drawing.Point(4, 22);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage5.Size = new System.Drawing.Size(984, 464);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "tabPage5";
            this.tabPage5.UseVisualStyleBackColor = true;
            this.tabPage5.Click += new System.EventHandler(this.tabPage5_Click);
            // 
            // textBox22
            // 
            this.textBox22.Location = new System.Drawing.Point(458, 49);
            this.textBox22.Name = "textBox22";
            this.textBox22.Size = new System.Drawing.Size(136, 20);
            this.textBox22.TabIndex = 62;
            // 
            // button9
            // 
            this.button9.BackColor = System.Drawing.Color.White;
            this.button9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button9.Location = new System.Drawing.Point(458, 75);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(65, 23);
            this.button9.TabIndex = 61;
            this.button9.Text = "Test";
            this.button9.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.button9.UseVisualStyleBackColor = false;
            this.button9.Click += new System.EventHandler(this.button9_Click_1);
            // 
            // materialRaisedButton36
            // 
            this.materialRaisedButton36.Depth = 0;
            this.materialRaisedButton36.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.materialRaisedButton36.ForeColor = System.Drawing.Color.CornflowerBlue;
            this.materialRaisedButton36.Location = new System.Drawing.Point(134, 324);
            this.materialRaisedButton36.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialRaisedButton36.Name = "materialRaisedButton36";
            this.materialRaisedButton36.Primary = true;
            this.materialRaisedButton36.Size = new System.Drawing.Size(131, 39);
            this.materialRaisedButton36.TabIndex = 59;
            this.materialRaisedButton36.Text = "Listen";
            this.materialRaisedButton36.UseVisualStyleBackColor = true;
            this.materialRaisedButton36.Click += new System.EventHandler(this.materialRaisedButton36_Click);
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.Color.White;
            this.button6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button6.Location = new System.Drawing.Point(597, 47);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(108, 22);
            this.button6.TabIndex = 56;
            this.button6.Text = "Open profile";
            this.button6.UseVisualStyleBackColor = false;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.White;
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button5.Location = new System.Drawing.Point(529, 75);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(65, 23);
            this.button5.TabIndex = 55;
            this.button5.Text = "All";
            this.button5.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // materialRaisedButton28
            // 
            this.materialRaisedButton28.Depth = 0;
            this.materialRaisedButton28.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.materialRaisedButton28.ForeColor = System.Drawing.Color.CornflowerBlue;
            this.materialRaisedButton28.Location = new System.Drawing.Point(134, 279);
            this.materialRaisedButton28.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialRaisedButton28.Name = "materialRaisedButton28";
            this.materialRaisedButton28.Primary = true;
            this.materialRaisedButton28.Size = new System.Drawing.Size(131, 39);
            this.materialRaisedButton28.TabIndex = 53;
            this.materialRaisedButton28.Text = "Check for freeloader";
            this.materialRaisedButton28.UseVisualStyleBackColor = true;
            this.materialRaisedButton28.Click += new System.EventHandler(this.materialRaisedButton28_Click);
            // 
            // checkBox6
            // 
            this.checkBox6.BackColor = System.Drawing.Color.White;
            this.checkBox6.Location = new System.Drawing.Point(208, 207);
            this.checkBox6.Name = "checkBox6";
            this.checkBox6.Size = new System.Drawing.Size(57, 21);
            this.checkBox6.TabIndex = 52;
            this.checkBox6.Text = "Crash";
            this.checkBox6.UseVisualStyleBackColor = false;
            // 
            // checkBox5
            // 
            this.checkBox5.BackColor = System.Drawing.Color.White;
            this.checkBox5.Location = new System.Drawing.Point(134, 208);
            this.checkBox5.Name = "checkBox5";
            this.checkBox5.Size = new System.Drawing.Size(57, 20);
            this.checkBox5.TabIndex = 51;
            this.checkBox5.Text = "Kick";
            this.checkBox5.UseVisualStyleBackColor = false;
            // 
            // listBox8
            // 
            this.listBox8.FormattingEnabled = true;
            this.listBox8.Location = new System.Drawing.Point(711, 29);
            this.listBox8.Name = "listBox8";
            this.listBox8.Size = new System.Drawing.Size(266, 69);
            this.listBox8.TabIndex = 48;
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(271, 419);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(131, 20);
            this.button7.TabIndex = 47;
            this.button7.Text = "Invite Spam";
            this.button7.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.White;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Location = new System.Drawing.Point(597, 75);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(108, 23);
            this.button3.TabIndex = 43;
            this.button3.Text = "Kick";
            this.button3.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // textBox16
            // 
            this.textBox16.Location = new System.Drawing.Point(545, 419);
            this.textBox16.Name = "textBox16";
            this.textBox16.Size = new System.Drawing.Size(131, 20);
            this.textBox16.TabIndex = 41;
            this.textBox16.Text = "SPAM";
            // 
            // textBox15
            // 
            this.textBox15.Location = new System.Drawing.Point(134, 77);
            this.textBox15.Name = "textBox15";
            this.textBox15.Size = new System.Drawing.Size(131, 20);
            this.textBox15.TabIndex = 40;
            this.textBox15.Text = "Fake SteamID";
            // 
            // listBox7
            // 
            this.listBox7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.listBox7.FormattingEnabled = true;
            this.listBox7.Location = new System.Drawing.Point(271, 101);
            this.listBox7.Name = "listBox7";
            this.listBox7.Size = new System.Drawing.Size(706, 288);
            this.listBox7.TabIndex = 39;
            // 
            // textBox12
            // 
            this.textBox12.Location = new System.Drawing.Point(134, 130);
            this.textBox12.Name = "textBox12";
            this.textBox12.Size = new System.Drawing.Size(131, 20);
            this.textBox12.TabIndex = 37;
            this.textBox12.Text = "Level";
            // 
            // materialRaisedButton20
            // 
            this.materialRaisedButton20.Depth = 0;
            this.materialRaisedButton20.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.materialRaisedButton20.ForeColor = System.Drawing.Color.CornflowerBlue;
            this.materialRaisedButton20.Location = new System.Drawing.Point(134, 234);
            this.materialRaisedButton20.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialRaisedButton20.Name = "materialRaisedButton20";
            this.materialRaisedButton20.Primary = true;
            this.materialRaisedButton20.Size = new System.Drawing.Size(131, 39);
            this.materialRaisedButton20.TabIndex = 36;
            this.materialRaisedButton20.Text = "Join lobby";
            this.materialRaisedButton20.UseVisualStyleBackColor = true;
            this.materialRaisedButton20.Click += new System.EventHandler(this.materialRaisedButton20_Click);
            // 
            // label7
            // 
            this.label7.BackColor = System.Drawing.Color.White;
            this.label7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label7.Location = new System.Drawing.Point(271, 6);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(706, 20);
            this.label7.TabIndex = 33;
            this.label7.Text = "Status";
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(893, 393);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(84, 20);
            this.button2.TabIndex = 24;
            this.button2.Text = "Send";
            this.button2.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // textBox14
            // 
            this.textBox14.Location = new System.Drawing.Point(271, 393);
            this.textBox14.Name = "textBox14";
            this.textBox14.Size = new System.Drawing.Size(616, 20);
            this.textBox14.TabIndex = 23;
            this.textBox14.Text = "Message";
            // 
            // label6
            // 
            this.label6.BackColor = System.Drawing.Color.White;
            this.label6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label6.Cursor = System.Windows.Forms.Cursors.Default;
            this.label6.Location = new System.Drawing.Point(271, 30);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(181, 68);
            this.label6.TabIndex = 22;
            this.label6.Text = "Searching status:";
            // 
            // materialRaisedButton18
            // 
            this.materialRaisedButton18.Depth = 0;
            this.materialRaisedButton18.ForeColor = System.Drawing.Color.CornflowerBlue;
            this.materialRaisedButton18.Location = new System.Drawing.Point(408, 419);
            this.materialRaisedButton18.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialRaisedButton18.Name = "materialRaisedButton18";
            this.materialRaisedButton18.Primary = true;
            this.materialRaisedButton18.Size = new System.Drawing.Size(131, 20);
            this.materialRaisedButton18.TabIndex = 21;
            this.materialRaisedButton18.Text = "Spam";
            this.materialRaisedButton18.UseVisualStyleBackColor = true;
            this.materialRaisedButton18.Click += new System.EventHandler(this.materialRaisedButton18_Click);
            // 
            // materialRaisedButton17
            // 
            this.materialRaisedButton17.Depth = 0;
            this.materialRaisedButton17.ForeColor = System.Drawing.Color.CornflowerBlue;
            this.materialRaisedButton17.Location = new System.Drawing.Point(134, 400);
            this.materialRaisedButton17.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialRaisedButton17.Name = "materialRaisedButton17";
            this.materialRaisedButton17.Primary = true;
            this.materialRaisedButton17.Size = new System.Drawing.Size(131, 39);
            this.materialRaisedButton17.TabIndex = 20;
            this.materialRaisedButton17.Text = "Crash lobby";
            this.materialRaisedButton17.UseVisualStyleBackColor = true;
            this.materialRaisedButton17.Click += new System.EventHandler(this.materialRaisedButton17_Click);
            // 
            // textBox13
            // 
            this.textBox13.Location = new System.Drawing.Point(134, 182);
            this.textBox13.Name = "textBox13";
            this.textBox13.Size = new System.Drawing.Size(131, 20);
            this.textBox13.TabIndex = 18;
            this.textBox13.Text = "Numbers of Wins";
            this.textBox13.TextChanged += new System.EventHandler(this.textBox13_TextChanged);
            // 
            // textBox11
            // 
            this.textBox11.Location = new System.Drawing.Point(134, 156);
            this.textBox11.Name = "textBox11";
            this.textBox11.Size = new System.Drawing.Size(131, 20);
            this.textBox11.TabIndex = 15;
            this.textBox11.Text = "Name";
            this.textBox11.TextChanged += new System.EventHandler(this.textBox11_TextChanged);
            // 
            // comboBox1
            // 
            this.comboBox1.Cursor = System.Windows.Forms.Cursors.Default;
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.comboBox1.Items.AddRange(new object[] {
            "NotRanked",
            "SilverI",
            "SilverII",
            "SilverIII",
            "SilverIV",
            "SilverElite",
            "SilverEliteMaster",
            "GoldNovaI",
            "GoldNovaII",
            "GoldNovaIII",
            "GoldNovaMaster",
            "MasterGuardianI",
            "MasterGuardianII",
            "MasterGuardianElite",
            "DistinguishedMasterGuardian",
            "LegendaryEagle",
            "LegendaryEagleMaster",
            "SupremeMasterFirstClass",
            "TheGlobalElite"});
            this.comboBox1.Location = new System.Drawing.Point(134, 103);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(131, 21);
            this.comboBox1.TabIndex = 1;
            this.comboBox1.Text = "NotRanked";
            // 
            // listBox6
            // 
            this.listBox6.FormattingEnabled = true;
            this.listBox6.Location = new System.Drawing.Point(8, 6);
            this.listBox6.Name = "listBox6";
            this.listBox6.Size = new System.Drawing.Size(120, 433);
            this.listBox6.TabIndex = 12;
            // 
            // textBox10
            // 
            this.textBox10.Location = new System.Drawing.Point(134, 51);
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new System.Drawing.Size(131, 20);
            this.textBox10.TabIndex = 10;
            this.textBox10.Text = "Lobby ID";
            // 
            // materialRaisedButton11
            // 
            this.materialRaisedButton11.Depth = 0;
            this.materialRaisedButton11.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.materialRaisedButton11.ForeColor = System.Drawing.Color.CornflowerBlue;
            this.materialRaisedButton11.Location = new System.Drawing.Point(134, 6);
            this.materialRaisedButton11.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialRaisedButton11.Name = "materialRaisedButton11";
            this.materialRaisedButton11.Primary = true;
            this.materialRaisedButton11.Size = new System.Drawing.Size(131, 39);
            this.materialRaisedButton11.TabIndex = 9;
            this.materialRaisedButton11.Text = "Connect";
            this.materialRaisedButton11.UseVisualStyleBackColor = true;
            this.materialRaisedButton11.Click += new System.EventHandler(this.materialRaisedButton11_Click);
            // 
            // tabPage6
            // 
            this.tabPage6.Controls.Add(this.materialRaisedButton39);
            this.tabPage6.Controls.Add(this.textBox26);
            this.tabPage6.Controls.Add(this.label18);
            this.tabPage6.Controls.Add(this.label17);
            this.tabPage6.Controls.Add(this.checkBox16);
            this.tabPage6.Controls.Add(this.checkBox15);
            this.tabPage6.Controls.Add(this.checkBox14);
            this.tabPage6.Controls.Add(this.label16);
            this.tabPage6.Controls.Add(this.checkBox13);
            this.tabPage6.Controls.Add(this.checkBox12);
            this.tabPage6.Controls.Add(this.materialRaisedButton35);
            this.tabPage6.Controls.Add(this.textBox25);
            this.tabPage6.Controls.Add(this.textBox24);
            this.tabPage6.Controls.Add(this.checkBox11);
            this.tabPage6.Controls.Add(this.checkBox7);
            this.tabPage6.Controls.Add(this.label15);
            this.tabPage6.Controls.Add(this.label14);
            this.tabPage6.Controls.Add(this.materialRaisedButton32);
            this.tabPage6.Controls.Add(this.label13);
            this.tabPage6.Controls.Add(this.materialRaisedButton31);
            this.tabPage6.Controls.Add(this.label12);
            this.tabPage6.Controls.Add(this.label11);
            this.tabPage6.Controls.Add(this.textBox21);
            this.tabPage6.Controls.Add(this.materialRaisedButton30);
            this.tabPage6.Controls.Add(this.materialRaisedButton29);
            this.tabPage6.Controls.Add(this.listBox13);
            this.tabPage6.Controls.Add(this.textBox20);
            this.tabPage6.Controls.Add(this.materialRaisedButton27);
            this.tabPage6.Controls.Add(this.materialRaisedButton26);
            this.tabPage6.Controls.Add(this.listBox12);
            this.tabPage6.Controls.Add(this.materialRaisedButton25);
            this.tabPage6.Controls.Add(this.materialRaisedButton24);
            this.tabPage6.Controls.Add(this.materialRaisedButton23);
            this.tabPage6.Controls.Add(this.listBox11);
            this.tabPage6.Controls.Add(this.textBox19);
            this.tabPage6.Controls.Add(this.textBox18);
            this.tabPage6.Controls.Add(this.label10);
            this.tabPage6.Controls.Add(this.label9);
            this.tabPage6.Controls.Add(this.label8);
            this.tabPage6.Controls.Add(this.materialRaisedButton22);
            this.tabPage6.Controls.Add(this.textBox17);
            this.tabPage6.Controls.Add(this.listBox10);
            this.tabPage6.Controls.Add(this.checkBox8);
            this.tabPage6.Controls.Add(this.checkBox9);
            this.tabPage6.Controls.Add(this.checkBox10);
            this.tabPage6.Controls.Add(this.materialRaisedButton21);
            this.tabPage6.Controls.Add(this.materialRaisedButton19);
            this.tabPage6.Controls.Add(this.label5);
            this.tabPage6.Controls.Add(this.listBox9);
            this.tabPage6.Location = new System.Drawing.Point(4, 22);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage6.Size = new System.Drawing.Size(984, 464);
            this.tabPage6.TabIndex = 5;
            this.tabPage6.Text = "tabPage6";
            this.tabPage6.UseVisualStyleBackColor = true;
            this.tabPage6.Click += new System.EventHandler(this.tabPage6_Click);
            // 
            // materialRaisedButton39
            // 
            this.materialRaisedButton39.Depth = 0;
            this.materialRaisedButton39.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.materialRaisedButton39.ForeColor = System.Drawing.Color.CornflowerBlue;
            this.materialRaisedButton39.Location = new System.Drawing.Point(527, 217);
            this.materialRaisedButton39.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialRaisedButton39.Name = "materialRaisedButton39";
            this.materialRaisedButton39.Primary = true;
            this.materialRaisedButton39.Size = new System.Drawing.Size(245, 69);
            this.materialRaisedButton39.TabIndex = 101;
            this.materialRaisedButton39.Text = "SCAN AND WRITING";
            this.materialRaisedButton39.UseVisualStyleBackColor = true;
            this.materialRaisedButton39.Click += new System.EventHandler(this.materialRaisedButton39_Click);
            // 
            // textBox26
            // 
            this.textBox26.Location = new System.Drawing.Point(526, 191);
            this.textBox26.Name = "textBox26";
            this.textBox26.Size = new System.Drawing.Size(246, 20);
            this.textBox26.TabIndex = 100;
            // 
            // label18
            // 
            this.label18.BackColor = System.Drawing.Color.White;
            this.label18.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label18.Location = new System.Drawing.Point(526, 166);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(246, 22);
            this.label18.TabIndex = 99;
            this.label18.Text = "Начал с";
            // 
            // label17
            // 
            this.label17.BackColor = System.Drawing.Color.White;
            this.label17.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label17.Location = new System.Drawing.Point(526, 99);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(246, 22);
            this.label17.TabIndex = 98;
            this.label17.Text = "Sended";
            // 
            // checkBox16
            // 
            this.checkBox16.AutoSize = true;
            this.checkBox16.BackColor = System.Drawing.Color.White;
            this.checkBox16.Location = new System.Drawing.Point(260, 194);
            this.checkBox16.Name = "checkBox16";
            this.checkBox16.Size = new System.Drawing.Size(88, 17);
            this.checkBox16.TabIndex = 97;
            this.checkBox16.Text = "Collect ID";
            this.checkBox16.UseVisualStyleBackColor = false;
            // 
            // checkBox15
            // 
            this.checkBox15.AutoSize = true;
            this.checkBox15.BackColor = System.Drawing.Color.White;
            this.checkBox15.Location = new System.Drawing.Point(778, 123);
            this.checkBox15.Name = "checkBox15";
            this.checkBox15.Size = new System.Drawing.Size(93, 17);
            this.checkBox15.TabIndex = 96;
            this.checkBox15.Text = "Own protector";
            this.checkBox15.UseVisualStyleBackColor = false;
            // 
            // checkBox14
            // 
            this.checkBox14.AutoSize = true;
            this.checkBox14.BackColor = System.Drawing.Color.White;
            this.checkBox14.Location = new System.Drawing.Point(778, 100);
            this.checkBox14.Name = "checkBox14";
            this.checkBox14.Size = new System.Drawing.Size(78, 17);
            this.checkBox14.TabIndex = 95;
            this.checkBox14.Text = "Own Slave";
            this.checkBox14.UseVisualStyleBackColor = false;
            // 
            // label16
            // 
            this.label16.BackColor = System.Drawing.Color.White;
            this.label16.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label16.Location = new System.Drawing.Point(526, 143);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(246, 22);
            this.label16.TabIndex = 94;
            this.label16.Text = "Crashed";
            // 
            // checkBox13
            // 
            this.checkBox13.AutoSize = true;
            this.checkBox13.BackColor = System.Drawing.Color.White;
            this.checkBox13.Location = new System.Drawing.Point(778, 77);
            this.checkBox13.Name = "checkBox13";
            this.checkBox13.Size = new System.Drawing.Size(85, 17);
            this.checkBox13.TabIndex = 93;
            this.checkBox13.Text = "Spam in LAC";
            this.checkBox13.UseVisualStyleBackColor = false;
            // 
            // checkBox12
            // 
            this.checkBox12.AutoSize = true;
            this.checkBox12.BackColor = System.Drawing.Color.White;
            this.checkBox12.Location = new System.Drawing.Point(778, 54);
            this.checkBox12.Name = "checkBox12";
            this.checkBox12.Size = new System.Drawing.Size(53, 17);
            this.checkBox12.TabIndex = 92;
            this.checkBox12.Text = "Spam";
            this.checkBox12.UseVisualStyleBackColor = false;
            this.checkBox12.CheckedChanged += new System.EventHandler(this.checkBox12_CheckedChanged);
            // 
            // materialRaisedButton35
            // 
            this.materialRaisedButton35.Depth = 0;
            this.materialRaisedButton35.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.materialRaisedButton35.ForeColor = System.Drawing.Color.CornflowerBlue;
            this.materialRaisedButton35.Location = new System.Drawing.Point(667, 54);
            this.materialRaisedButton35.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialRaisedButton35.Name = "materialRaisedButton35";
            this.materialRaisedButton35.Primary = true;
            this.materialRaisedButton35.Size = new System.Drawing.Size(105, 42);
            this.materialRaisedButton35.TabIndex = 91;
            this.materialRaisedButton35.Text = "LAC";
            this.materialRaisedButton35.UseVisualStyleBackColor = true;
            this.materialRaisedButton35.Click += new System.EventHandler(this.materialRaisedButton35_Click);
            // 
            // textBox25
            // 
            this.textBox25.Location = new System.Drawing.Point(260, 128);
            this.textBox25.Name = "textBox25";
            this.textBox25.Size = new System.Drawing.Size(120, 20);
            this.textBox25.TabIndex = 90;
            this.textBox25.Text = "acces_token";
            this.textBox25.TextChanged += new System.EventHandler(this.textBox25_TextChanged);
            // 
            // textBox24
            // 
            this.textBox24.Location = new System.Drawing.Point(260, 102);
            this.textBox24.Name = "textBox24";
            this.textBox24.Size = new System.Drawing.Size(120, 20);
            this.textBox24.TabIndex = 89;
            this.textBox24.Text = "100";
            // 
            // checkBox11
            // 
            this.checkBox11.AutoSize = true;
            this.checkBox11.BackColor = System.Drawing.Color.White;
            this.checkBox11.Location = new System.Drawing.Point(450, 269);
            this.checkBox11.Name = "checkBox11";
            this.checkBox11.Size = new System.Drawing.Size(71, 17);
            this.checkBox11.TabIndex = 88;
            this.checkBox11.Text = "Freeloaders";
            this.checkBox11.UseVisualStyleBackColor = false;
            // 
            // checkBox7
            // 
            this.checkBox7.AutoSize = true;
            this.checkBox7.BackColor = System.Drawing.Color.White;
            this.checkBox7.Location = new System.Drawing.Point(386, 269);
            this.checkBox7.Name = "checkBox7";
            this.checkBox7.Size = new System.Drawing.Size(83, 17);
            this.checkBox7.TabIndex = 87;
            this.checkBox7.Text = "Freeloaders";
            this.checkBox7.UseVisualStyleBackColor = false;
            // 
            // label15
            // 
            this.label15.BackColor = System.Drawing.Color.White;
            this.label15.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label15.Location = new System.Drawing.Point(387, 246);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(134, 20);
            this.label15.TabIndex = 86;
            this.label15.Text = "Banned:";
            // 
            // label14
            // 
            this.label14.BackColor = System.Drawing.Color.White;
            this.label14.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label14.Location = new System.Drawing.Point(387, 222);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(134, 20);
            this.label14.TabIndex = 85;
            this.label14.Text = "Checked:";
            // 
            // materialRaisedButton32
            // 
            this.materialRaisedButton32.Depth = 0;
            this.materialRaisedButton32.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.materialRaisedButton32.ForeColor = System.Drawing.Color.CornflowerBlue;
            this.materialRaisedButton32.Location = new System.Drawing.Point(387, 194);
            this.materialRaisedButton32.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialRaisedButton32.Name = "materialRaisedButton32";
            this.materialRaisedButton32.Primary = true;
            this.materialRaisedButton32.Size = new System.Drawing.Size(134, 20);
            this.materialRaisedButton32.TabIndex = 84;
            this.materialRaisedButton32.Text = "Check list";
            this.materialRaisedButton32.UseVisualStyleBackColor = true;
            this.materialRaisedButton32.Click += new System.EventHandler(this.materialRaisedButton32_Click);
            // 
            // label13
            // 
            this.label13.BackColor = System.Drawing.Color.White;
            this.label13.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label13.Location = new System.Drawing.Point(526, 121);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(246, 22);
            this.label13.TabIndex = 83;
            this.label13.Text = "Joined";
            // 
            // materialRaisedButton31
            // 
            this.materialRaisedButton31.Depth = 0;
            this.materialRaisedButton31.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.materialRaisedButton31.ForeColor = System.Drawing.Color.CornflowerBlue;
            this.materialRaisedButton31.Location = new System.Drawing.Point(526, 54);
            this.materialRaisedButton31.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialRaisedButton31.Name = "materialRaisedButton31";
            this.materialRaisedButton31.Primary = true;
            this.materialRaisedButton31.Size = new System.Drawing.Size(135, 42);
            this.materialRaisedButton31.TabIndex = 80;
            this.materialRaisedButton31.Text = "Search in lobby";
            this.materialRaisedButton31.UseVisualStyleBackColor = true;
            this.materialRaisedButton31.Click += new System.EventHandler(this.materialRaisedButton31_Click);
            // 
            // label12
            // 
            this.label12.BackColor = System.Drawing.Color.White;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label12.Location = new System.Drawing.Point(778, 420);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(100, 22);
            this.label12.TabIndex = 79;
            this.label12.Text = "BlackList:";
            // 
            // label11
            // 
            this.label11.BackColor = System.Drawing.Color.White;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label11.Location = new System.Drawing.Point(509, 417);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(100, 22);
            this.label11.TabIndex = 78;
            this.label11.Text = "WhiteList:";
            // 
            // textBox21
            // 
            this.textBox21.Location = new System.Drawing.Point(778, 294);
            this.textBox21.Name = "textBox21";
            this.textBox21.Size = new System.Drawing.Size(135, 20);
            this.textBox21.TabIndex = 77;
            this.textBox21.Text = "Steam64ID";
            // 
            // materialRaisedButton30
            // 
            this.materialRaisedButton30.Depth = 0;
            this.materialRaisedButton30.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.materialRaisedButton30.ForeColor = System.Drawing.Color.CornflowerBlue;
            this.materialRaisedButton30.Location = new System.Drawing.Point(778, 346);
            this.materialRaisedButton30.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialRaisedButton30.Name = "materialRaisedButton30";
            this.materialRaisedButton30.Primary = true;
            this.materialRaisedButton30.Size = new System.Drawing.Size(135, 20);
            this.materialRaisedButton30.TabIndex = 76;
            this.materialRaisedButton30.Text = "Remove";
            this.materialRaisedButton30.UseVisualStyleBackColor = true;
            this.materialRaisedButton30.Click += new System.EventHandler(this.materialRaisedButton30_Click);
            // 
            // materialRaisedButton29
            // 
            this.materialRaisedButton29.Depth = 0;
            this.materialRaisedButton29.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.materialRaisedButton29.ForeColor = System.Drawing.Color.CornflowerBlue;
            this.materialRaisedButton29.Location = new System.Drawing.Point(778, 320);
            this.materialRaisedButton29.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialRaisedButton29.Name = "materialRaisedButton29";
            this.materialRaisedButton29.Primary = true;
            this.materialRaisedButton29.Size = new System.Drawing.Size(135, 20);
            this.materialRaisedButton29.TabIndex = 75;
            this.materialRaisedButton29.Text = "Add";
            this.materialRaisedButton29.UseVisualStyleBackColor = true;
            this.materialRaisedButton29.Click += new System.EventHandler(this.materialRaisedButton29_Click);
            // 
            // listBox13
            // 
            this.listBox13.FormattingEnabled = true;
            this.listBox13.Location = new System.Drawing.Point(652, 294);
            this.listBox13.Name = "listBox13";
            this.listBox13.Size = new System.Drawing.Size(120, 147);
            this.listBox13.TabIndex = 74;
            // 
            // textBox20
            // 
            this.textBox20.Location = new System.Drawing.Point(512, 292);
            this.textBox20.Name = "textBox20";
            this.textBox20.Size = new System.Drawing.Size(135, 20);
            this.textBox20.TabIndex = 73;
            this.textBox20.Text = "Steam64ID";
            // 
            // materialRaisedButton27
            // 
            this.materialRaisedButton27.Depth = 0;
            this.materialRaisedButton27.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.materialRaisedButton27.ForeColor = System.Drawing.Color.CornflowerBlue;
            this.materialRaisedButton27.Location = new System.Drawing.Point(512, 346);
            this.materialRaisedButton27.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialRaisedButton27.Name = "materialRaisedButton27";
            this.materialRaisedButton27.Primary = true;
            this.materialRaisedButton27.Size = new System.Drawing.Size(135, 20);
            this.materialRaisedButton27.TabIndex = 72;
            this.materialRaisedButton27.Text = "Remove";
            this.materialRaisedButton27.UseVisualStyleBackColor = true;
            this.materialRaisedButton27.Click += new System.EventHandler(this.materialRaisedButton27_Click);
            // 
            // materialRaisedButton26
            // 
            this.materialRaisedButton26.Depth = 0;
            this.materialRaisedButton26.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.materialRaisedButton26.ForeColor = System.Drawing.Color.CornflowerBlue;
            this.materialRaisedButton26.Location = new System.Drawing.Point(512, 318);
            this.materialRaisedButton26.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialRaisedButton26.Name = "materialRaisedButton26";
            this.materialRaisedButton26.Primary = true;
            this.materialRaisedButton26.Size = new System.Drawing.Size(135, 20);
            this.materialRaisedButton26.TabIndex = 71;
            this.materialRaisedButton26.Text = "Add";
            this.materialRaisedButton26.UseVisualStyleBackColor = true;
            this.materialRaisedButton26.Click += new System.EventHandler(this.materialRaisedButton26_Click);
            // 
            // listBox12
            // 
            this.listBox12.FormattingEnabled = true;
            this.listBox12.Location = new System.Drawing.Point(386, 292);
            this.listBox12.Name = "listBox12";
            this.listBox12.Size = new System.Drawing.Size(120, 147);
            this.listBox12.TabIndex = 70;
            // 
            // materialRaisedButton25
            // 
            this.materialRaisedButton25.Depth = 0;
            this.materialRaisedButton25.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.materialRaisedButton25.ForeColor = System.Drawing.Color.CornflowerBlue;
            this.materialRaisedButton25.Location = new System.Drawing.Point(134, 29);
            this.materialRaisedButton25.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialRaisedButton25.Name = "materialRaisedButton25";
            this.materialRaisedButton25.Primary = true;
            this.materialRaisedButton25.Size = new System.Drawing.Size(844, 19);
            this.materialRaisedButton25.TabIndex = 69;
            this.materialRaisedButton25.Text = "Connect";
            this.materialRaisedButton25.UseVisualStyleBackColor = true;
            this.materialRaisedButton25.Click += new System.EventHandler(this.materialRaisedButton25_Click);
            // 
            // materialRaisedButton24
            // 
            this.materialRaisedButton24.Depth = 0;
            this.materialRaisedButton24.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.materialRaisedButton24.ForeColor = System.Drawing.Color.CornflowerBlue;
            this.materialRaisedButton24.Location = new System.Drawing.Point(260, 281);
            this.materialRaisedButton24.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialRaisedButton24.Name = "materialRaisedButton24";
            this.materialRaisedButton24.Primary = true;
            this.materialRaisedButton24.Size = new System.Drawing.Size(120, 39);
            this.materialRaisedButton24.TabIndex = 68;
            this.materialRaisedButton24.Text = "Crash";
            this.materialRaisedButton24.UseVisualStyleBackColor = true;
            this.materialRaisedButton24.Click += new System.EventHandler(this.materialRaisedButton24_Click);
            // 
            // materialRaisedButton23
            // 
            this.materialRaisedButton23.Depth = 0;
            this.materialRaisedButton23.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.materialRaisedButton23.ForeColor = System.Drawing.Color.CornflowerBlue;
            this.materialRaisedButton23.Location = new System.Drawing.Point(260, 255);
            this.materialRaisedButton23.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialRaisedButton23.Name = "materialRaisedButton23";
            this.materialRaisedButton23.Primary = true;
            this.materialRaisedButton23.Size = new System.Drawing.Size(120, 20);
            this.materialRaisedButton23.TabIndex = 67;
            this.materialRaisedButton23.Text = "Add";
            this.materialRaisedButton23.UseVisualStyleBackColor = true;
            this.materialRaisedButton23.Click += new System.EventHandler(this.materialRaisedButton23_Click);
            // 
            // listBox11
            // 
            this.listBox11.FormattingEnabled = true;
            this.listBox11.Location = new System.Drawing.Point(134, 229);
            this.listBox11.Name = "listBox11";
            this.listBox11.Size = new System.Drawing.Size(120, 147);
            this.listBox11.TabIndex = 66;
            // 
            // textBox19
            // 
            this.textBox19.Location = new System.Drawing.Point(260, 229);
            this.textBox19.Name = "textBox19";
            this.textBox19.Size = new System.Drawing.Size(120, 20);
            this.textBox19.TabIndex = 65;
            this.textBox19.Text = "Link to profile";
            // 
            // textBox18
            // 
            this.textBox18.Location = new System.Drawing.Point(386, 168);
            this.textBox18.Name = "textBox18";
            this.textBox18.Size = new System.Drawing.Size(135, 20);
            this.textBox18.TabIndex = 64;
            this.textBox18.Text = "Message on join";
            // 
            // label10
            // 
            this.label10.BackColor = System.Drawing.Color.White;
            this.label10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label10.Location = new System.Drawing.Point(134, 379);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(246, 20);
            this.label10.TabIndex = 63;
            this.label10.Text = "Kicked:";
            // 
            // label9
            // 
            this.label9.BackColor = System.Drawing.Color.White;
            this.label9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label9.Location = new System.Drawing.Point(134, 419);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(246, 20);
            this.label9.TabIndex = 62;
            this.label9.Text = "Lobby crashed:";
            // 
            // label8
            // 
            this.label8.BackColor = System.Drawing.Color.White;
            this.label8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label8.Location = new System.Drawing.Point(134, 399);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(246, 20);
            this.label8.TabIndex = 61;
            this.label8.Text = "Writed SteamID:";
            // 
            // materialRaisedButton22
            // 
            this.materialRaisedButton22.Depth = 0;
            this.materialRaisedButton22.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.materialRaisedButton22.ForeColor = System.Drawing.Color.CornflowerBlue;
            this.materialRaisedButton22.Location = new System.Drawing.Point(134, 54);
            this.materialRaisedButton22.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialRaisedButton22.Name = "materialRaisedButton22";
            this.materialRaisedButton22.Primary = true;
            this.materialRaisedButton22.Size = new System.Drawing.Size(246, 20);
            this.materialRaisedButton22.TabIndex = 59;
            this.materialRaisedButton22.Text = "Add";
            this.materialRaisedButton22.UseVisualStyleBackColor = true;
            this.materialRaisedButton22.Click += new System.EventHandler(this.materialRaisedButton22_Click);
            // 
            // textBox17
            // 
            this.textBox17.Location = new System.Drawing.Point(260, 76);
            this.textBox17.Name = "textBox17";
            this.textBox17.Size = new System.Drawing.Size(120, 20);
            this.textBox17.TabIndex = 58;
            this.textBox17.Text = "VK group ID:";
            // 
            // listBox10
            // 
            this.listBox10.FormattingEnabled = true;
            this.listBox10.Location = new System.Drawing.Point(134, 76);
            this.listBox10.Name = "listBox10";
            this.listBox10.Size = new System.Drawing.Size(120, 147);
            this.listBox10.TabIndex = 57;
            // 
            // checkBox8
            // 
            this.checkBox8.AutoSize = true;
            this.checkBox8.BackColor = System.Drawing.Color.White;
            this.checkBox8.Location = new System.Drawing.Point(386, 99);
            this.checkBox8.Name = "checkBox8";
            this.checkBox8.Size = new System.Drawing.Size(95, 17);
            this.checkBox8.TabIndex = 56;
            this.checkBox8.Text = "Fill lobby";
            this.checkBox8.UseVisualStyleBackColor = false;
            // 
            // checkBox9
            // 
            this.checkBox9.AutoSize = true;
            this.checkBox9.BackColor = System.Drawing.Color.White;
            this.checkBox9.Location = new System.Drawing.Point(386, 145);
            this.checkBox9.Name = "checkBox9";
            this.checkBox9.Size = new System.Drawing.Size(80, 17);
            this.checkBox9.TabIndex = 55;
            this.checkBox9.Text = "Auto Crash";
            this.checkBox9.UseVisualStyleBackColor = false;
            // 
            // checkBox10
            // 
            this.checkBox10.AutoSize = true;
            this.checkBox10.BackColor = System.Drawing.Color.White;
            this.checkBox10.Location = new System.Drawing.Point(386, 122);
            this.checkBox10.Name = "checkBox10";
            this.checkBox10.Size = new System.Drawing.Size(69, 17);
            this.checkBox10.TabIndex = 54;
            this.checkBox10.Text = "Auto Kick";
            this.checkBox10.UseVisualStyleBackColor = false;
            // 
            // materialRaisedButton21
            // 
            this.materialRaisedButton21.Depth = 0;
            this.materialRaisedButton21.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.materialRaisedButton21.ForeColor = System.Drawing.Color.CornflowerBlue;
            this.materialRaisedButton21.Location = new System.Drawing.Point(386, 54);
            this.materialRaisedButton21.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialRaisedButton21.Name = "materialRaisedButton21";
            this.materialRaisedButton21.Primary = true;
            this.materialRaisedButton21.Size = new System.Drawing.Size(135, 39);
            this.materialRaisedButton21.TabIndex = 36;
            this.materialRaisedButton21.Text = "FUCK IT UP";
            this.materialRaisedButton21.UseVisualStyleBackColor = true;
            this.materialRaisedButton21.Click += new System.EventHandler(this.materialRaisedButton21_Click);
            // 
            // materialRaisedButton19
            // 
            this.materialRaisedButton19.Depth = 0;
            this.materialRaisedButton19.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.materialRaisedButton19.ForeColor = System.Drawing.Color.CornflowerBlue;
            this.materialRaisedButton19.Location = new System.Drawing.Point(260, 154);
            this.materialRaisedButton19.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialRaisedButton19.Name = "materialRaisedButton19";
            this.materialRaisedButton19.Primary = true;
            this.materialRaisedButton19.Size = new System.Drawing.Size(120, 34);
            this.materialRaisedButton19.TabIndex = 35;
            this.materialRaisedButton19.Text = "Start Overwatch";
            this.materialRaisedButton19.UseVisualStyleBackColor = true;
            this.materialRaisedButton19.Click += new System.EventHandler(this.materialRaisedButton19_Click_1);
            // 
            // label5
            // 
            this.label5.BackColor = System.Drawing.Color.White;
            this.label5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label5.Location = new System.Drawing.Point(134, 6);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(844, 20);
            this.label5.TabIndex = 34;
            this.label5.Text = "Status";
            // 
            // listBox9
            // 
            this.listBox9.FormattingEnabled = true;
            this.listBox9.Location = new System.Drawing.Point(8, 6);
            this.listBox9.Name = "listBox9";
            this.listBox9.Size = new System.Drawing.Size(120, 433);
            this.listBox9.TabIndex = 13;
            // 
            // tabPage7
            // 
            this.tabPage7.Controls.Add(this.materialRaisedButton38);
            this.tabPage7.Controls.Add(this.textBox23);
            this.tabPage7.Controls.Add(this.materialRaisedButton37);
            this.tabPage7.Location = new System.Drawing.Point(4, 22);
            this.tabPage7.Name = "tabPage7";
            this.tabPage7.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage7.Size = new System.Drawing.Size(984, 464);
            this.tabPage7.TabIndex = 6;
            this.tabPage7.Text = "---";
            this.tabPage7.UseVisualStyleBackColor = true;
            // 
            // materialRaisedButton38
            // 
            this.materialRaisedButton38.Depth = 0;
            this.materialRaisedButton38.Location = new System.Drawing.Point(132, 29);
            this.materialRaisedButton38.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialRaisedButton38.Name = "materialRaisedButton38";
            this.materialRaisedButton38.Primary = true;
            this.materialRaisedButton38.Size = new System.Drawing.Size(122, 23);
            this.materialRaisedButton38.TabIndex = 2;
            this.materialRaisedButton38.Text = "materialRaisedButton38";
            this.materialRaisedButton38.UseVisualStyleBackColor = true;
            // 
            // textBox23
            // 
            this.textBox23.Location = new System.Drawing.Point(6, 3);
            this.textBox23.Name = "textBox23";
            this.textBox23.Size = new System.Drawing.Size(250, 20);
            this.textBox23.TabIndex = 1;
            // 
            // materialRaisedButton37
            // 
            this.materialRaisedButton37.Depth = 0;
            this.materialRaisedButton37.Location = new System.Drawing.Point(6, 29);
            this.materialRaisedButton37.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialRaisedButton37.Name = "materialRaisedButton37";
            this.materialRaisedButton37.Primary = true;
            this.materialRaisedButton37.Size = new System.Drawing.Size(120, 23);
            this.materialRaisedButton37.TabIndex = 0;
            this.materialRaisedButton37.Text = "materialRaisedButton37";
            this.materialRaisedButton37.UseVisualStyleBackColor = true;
            // 
            // folderBrowserDialog1
            // 
            this.folderBrowserDialog1.HelpRequest += new System.EventHandler(this.folderBrowserDialog1_HelpRequest);
            // 
            // mainform
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlDark;
            this.ClientSize = new System.Drawing.Size(993, 557);
            this.Controls.Add(this.materialTabSelector1);
            this.Controls.Add(this.materialTabControl1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "mainform";
            this.Text = " ";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.mainform_FormClosing);
            this.Load += new System.EventHandler(this.mainform_Load);
            this.Enter += new System.EventHandler(this.mainform_Enter);
            this.materialTabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.tabPage4.ResumeLayout(false);
            this.tabPage5.ResumeLayout(false);
            this.tabPage5.PerformLayout();
            this.tabPage6.ResumeLayout(false);
            this.tabPage6.PerformLayout();
            this.tabPage7.ResumeLayout(false);
            this.tabPage7.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private MaterialSkin.Controls.MaterialTabSelector materialTabSelector1;
        private System.Windows.Forms.Timer timer1;
        private MaterialSkin.Controls.MaterialTabControl materialTabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private MaterialSkin.Controls.MaterialRaisedButton materialRaisedButton8;
        private MaterialSkin.Controls.MaterialRaisedButton launchsteam;
        private MaterialSkin.Controls.MaterialRaisedButton launchcsgo;
        private MaterialSkin.Controls.MaterialRaisedButton button1;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.TabPage tabPage2;
        private MaterialSkin.Controls.MaterialLabel materialLabel1;
        private MaterialSkin.Controls.MaterialRaisedButton materialRaisedButton16;
        private MaterialSkin.Controls.MaterialRaisedButton materialRaisedButton15;
        private MaterialSkin.Controls.MaterialRaisedButton materialRaisedButton14;
        private System.Windows.Forms.CheckBox checkBox4;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.TextBox textBox3;
        public System.Windows.Forms.TextBox textBox6;
        public System.Windows.Forms.TextBox textBox5;
        public System.Windows.Forms.TextBox textBox4;
        public System.Windows.Forms.TextBox textBox2;
        public System.Windows.Forms.TextBox textBox1;
        public System.Windows.Forms.Label label3;
        private MaterialSkin.Controls.MaterialLabel materialLabel3;
        private MaterialSkin.Controls.MaterialLabel materialLabel2;
        private MaterialSkin.Controls.MaterialRaisedButton materialRaisedButton4;
        private MaterialSkin.Controls.MaterialRaisedButton materialRaisedButton3;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.CheckBox checkBox3;
        private System.Windows.Forms.CheckBox checkBox2;
        private MaterialSkin.Controls.MaterialRaisedButton materialRaisedButton2;
        private MaterialSkin.Controls.MaterialRaisedButton materialRaisedButton1;
        private System.Windows.Forms.ListBox listBox3;
        private System.Windows.Forms.ListBox listBox2;
        private System.Windows.Forms.TabPage tabPage3;
        private MaterialSkin.Controls.MaterialRaisedButton materialRaisedButton10;
        private MaterialSkin.Controls.MaterialRaisedButton materialRaisedButton9;
        private System.Windows.Forms.ListBox listBox4;
        private System.Windows.Forms.TabPage tabPage4;
        private MaterialSkin.Controls.MaterialRaisedButton materialRaisedButton13;
        private MaterialSkin.Controls.MaterialRaisedButton materialRaisedButton12;
        private System.Windows.Forms.ListBox listBox5;
        private System.Windows.Forms.FolderBrowserDialog folderBrowserDialog1;
        private System.Windows.Forms.TextBox textBox9;
        private MaterialSkin.Controls.MaterialRaisedButton materialRaisedButton5;
        private MaterialSkin.Controls.MaterialRaisedButton materialRaisedButton6;
        private MaterialSkin.Controls.MaterialRaisedButton materialRaisedButton7;
        public System.Windows.Forms.Label label1;
        public System.Windows.Forms.Label label2;
        public System.Windows.Forms.Label label4;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.Label label6;
        private MaterialSkin.Controls.MaterialRaisedButton materialRaisedButton18;
        private MaterialSkin.Controls.MaterialRaisedButton materialRaisedButton17;
        private System.Windows.Forms.TextBox textBox13;
        private System.Windows.Forms.TextBox textBox11;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.ListBox listBox6;
        private System.Windows.Forms.TextBox textBox10;
        private MaterialSkin.Controls.MaterialRaisedButton materialRaisedButton11;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TextBox textBox14;
        private System.Windows.Forms.Timer timer2;
        public System.Windows.Forms.Label label7;
        private MaterialSkin.Controls.MaterialRaisedButton materialRaisedButton20;
        private System.Windows.Forms.TextBox textBox12;
        private System.Windows.Forms.ListBox listBox7;
        private System.Windows.Forms.TextBox textBox15;
        private System.Windows.Forms.TextBox textBox16;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.ListBox listBox8;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.CheckBox checkBox5;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.CheckBox checkBox6;
        private MaterialSkin.Controls.MaterialRaisedButton materialRaisedButton21;
        private MaterialSkin.Controls.MaterialRaisedButton materialRaisedButton19;
        public System.Windows.Forms.Label label5;
        private System.Windows.Forms.ListBox listBox9;
        private MaterialSkin.Controls.MaterialRaisedButton materialRaisedButton24;
        private MaterialSkin.Controls.MaterialRaisedButton materialRaisedButton23;
        private System.Windows.Forms.ListBox listBox11;
        private System.Windows.Forms.TextBox textBox19;
        private System.Windows.Forms.TextBox textBox18;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private MaterialSkin.Controls.MaterialRaisedButton materialRaisedButton22;
        private System.Windows.Forms.TextBox textBox17;
        private System.Windows.Forms.ListBox listBox10;
        private System.Windows.Forms.CheckBox checkBox8;
        private System.Windows.Forms.CheckBox checkBox9;
        private System.Windows.Forms.CheckBox checkBox10;
        private MaterialSkin.Controls.MaterialRaisedButton materialRaisedButton25;
        private System.Windows.Forms.TextBox textBox20;
        private MaterialSkin.Controls.MaterialRaisedButton materialRaisedButton27;
        private MaterialSkin.Controls.MaterialRaisedButton materialRaisedButton26;
        private System.Windows.Forms.ListBox listBox12;
        private MaterialSkin.Controls.MaterialRaisedButton materialRaisedButton28;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox textBox21;
        private MaterialSkin.Controls.MaterialRaisedButton materialRaisedButton30;
        private MaterialSkin.Controls.MaterialRaisedButton materialRaisedButton29;
        private System.Windows.Forms.ListBox listBox13;
        private MaterialSkin.Controls.MaterialRaisedButton materialRaisedButton31;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private MaterialSkin.Controls.MaterialRaisedButton materialRaisedButton32;
        private System.Windows.Forms.CheckBox checkBox11;
        private System.Windows.Forms.CheckBox checkBox7;
        private System.Windows.Forms.TextBox textBox25;
        private System.Windows.Forms.TextBox textBox24;
        private System.Windows.Forms.FolderBrowserDialog folderBrowserDialog2;
        private MaterialSkin.Controls.MaterialRaisedButton materialRaisedButton34;
        private MaterialSkin.Controls.MaterialRaisedButton materialRaisedButton33;
        private MaterialSkin.Controls.MaterialRaisedButton materialRaisedButton35;
        private System.Windows.Forms.CheckBox checkBox12;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.CheckBox checkBox13;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.CheckBox checkBox14;
        private MaterialSkin.Controls.MaterialRaisedButton materialRaisedButton36;
        private System.Windows.Forms.CheckBox checkBox15;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.TextBox textBox22;
        private System.Windows.Forms.CheckBox checkBox16;
        private System.Windows.Forms.TabPage tabPage7;
        private MaterialSkin.Controls.MaterialRaisedButton materialRaisedButton38;
        private System.Windows.Forms.TextBox textBox23;
        private MaterialSkin.Controls.MaterialRaisedButton materialRaisedButton37;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox textBox26;
        private MaterialSkin.Controls.MaterialRaisedButton materialRaisedButton39;
    }
}

