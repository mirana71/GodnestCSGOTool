# RIP 2/18/2017
<br />
<br />
### GodnestCSGOTool
lobby bots full source code

### Dependency

Mail.dll <br />
MaterialSkin <br />
Newtonsoft.Json <br />
protobuf-net <br />
SteamAuth <br />
SteamKit2 <br />
